module.exports = { greet: () => "hello from tarball" };
