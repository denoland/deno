// Mock of the jsdom npm package used to test `deno test --dom=jsdom` wiring.
const VERSION = require("./package.json").version;

class Event {
  static mockDomLibrary = "jsdom";
  constructor(type, init = {}) {
    this.type = type;
    this.bubbles = !!init.bubbles;
  }
}
class FormData {
  static mockDomLibrary = "jsdom";
}
class HTMLElement {
  constructor(tagName) {
    this.tagName = tagName;
  }
}

class JSDOM {
  constructor(html = "", options = {}) {
    this.html = html;
    this.options = options;
    const window = {
      Event,
      FormData,
      HTMLElement,
      location: { href: options.url ?? "about:blank" },
      history: { length: 1 },
      document: {
        mockDomLibrary: "jsdom",
        version: VERSION,
        createElement(tagName) {
          return new HTMLElement(tagName.toUpperCase());
        },
      },
      getWindow() {
        return window;
      },
    };
    window.fetch = function mockFetch() {
      throw new Error("mock fetch");
    };
    window.fetch.mockDomLibrary = "jsdom";
    window.document.defaultView = window;
    this.window = window;
  }
}

module.exports = { JSDOM };
