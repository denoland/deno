// Mock of the happy-dom npm package used to test `deno test --dom` wiring.
const VERSION = require("./package.json").version;

class Event {
  static mockDomLibrary = "happy-dom";
  constructor(type, init = {}) {
    this.type = type;
    this.bubbles = !!init.bubbles;
  }
}
class CustomEvent extends Event {
  constructor(type, init = {}) {
    super(type, init);
    this.detail = init.detail;
  }
}
class EventTarget {
  static mockDomLibrary = "happy-dom";
}
class FormData {
  static mockDomLibrary = "happy-dom";
}
class HTMLElement {
  constructor(tagName) {
    this.tagName = tagName;
  }
}

class GlobalWindow {
  constructor(options = {}) {
    const window = this;
    this.happyDOM = {
      version: VERSION,
      settings: options.settings ?? {},
    };
    this.Event = Event;
    this.CustomEvent = CustomEvent;
    this.EventTarget = EventTarget;
    this.FormData = FormData;
    this.HTMLElement = HTMLElement;
    this.location = { href: options.url ?? "about:blank" };
    this.history = { length: 1 };
    this.document = {
      mockDomLibrary: "happy-dom",
      version: VERSION,
      createElement(tagName) {
        return new HTMLElement(tagName.toUpperCase());
      },
    };
    this.fetch = function mockFetch() {
      throw new Error("mock fetch");
    };
    this.fetch.mockDomLibrary = "happy-dom";
    this.getWindow = function () {
      return window;
    };
  }
}

module.exports = { GlobalWindow, Window: GlobalWindow };
