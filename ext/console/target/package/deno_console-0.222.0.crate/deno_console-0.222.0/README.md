# deno_console

This crate has been deprecated, use
[deno_web](https://crates.io/crates/deno_web) instead.
